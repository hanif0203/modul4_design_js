// import { View } from "react-native";
import { View } from "@gluestack-ui/themed";
// Functional Component with props
const Separator = (props) => {
  return <View style={{ height: props.height }}></View>;
};

export default Separator;